
## lab4




Accept the Github Classroom assignnment at 
[url.cs51.io/lab4](http://url.cs51.io/lab4). 

If this does not work _and a TF advises_, fork and then clone the repository at 
[http://github.com/cs51/lab4](http://github.com/cs51/lab4) 
and proceed as usual.

