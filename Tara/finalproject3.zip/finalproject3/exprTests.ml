open Expr ;;

(* MiniML examples to test *)

(* Free variables *)
let x = Var "x" ;;
let y = Var "y" ;;
let z = Var "z" ;;
let one = Num 1 ;;
let two = Num 2 ;;
let three = Num 3 ;;

(* Expressions to test *)
let xPlusY = Binop (Plus, x, y) ;;
let zTimes2 = Binop (Times, z, two) ;;

(* Testing free_vars *)

(* Testing subs *)
let xSub1 = Binop (Plus, one, y) ;;

(* The tests! *)
assert (free_vars xPlusY = vars_of_list ["x"; "y"]) ;; 
assert (subst "x" one xPlusY = xSub1) ;;