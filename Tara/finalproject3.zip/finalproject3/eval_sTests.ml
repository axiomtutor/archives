open Evaluation ;;

Var of varid                         (* variables *)
  | Num of int                           (* integers *)
  | Bool of bool                         (* booleans *)
  | Unop of unop * expr                  (* unary operators *)
  | Binop of binop * expr * expr         (* binary operators *)
  | Conditional of expr * expr * expr    (* if then else *)
  | Fun of varid * expr                  (* function definitions *)
  | Let of varid * expr * expr           (* local naming *)
  | Letrec of varid * expr * expr        (* recursive local naming *)
  | Raise                                (* exceptions *)
  | Unassigned                           (* (temporarily) unassigned *)
  | App


(* Var id -> id *)

(* Num n -> n *)

(* Bool b -> b *)

(* Unop 1 negate n -> -1 * n *)
(* Unop 2 negate b -> Unassigned *)
(* Uunop 3 negate Unassigned -> Unassigned *)

(* Binop (+) n1 n2 -> n1 + n2 *)
(* Binop (-) n1 n2 -> n1 - n2 *)
(* Binop (*) n1 n2 -> n1 * n2 *)
(* Binop (=) n1 n1 -> true *)
(* Binop (=) n1 n2 -> false *)
(* Binop (<) n1 n2 -> true *)

(* Conditional if i then t else e -> t *)
(* Conditional if i then t else e -> e *)

(* Fun -> Fun *)

(* App (5) of fun = x+1 -> 6 *)