open Streamstrees

