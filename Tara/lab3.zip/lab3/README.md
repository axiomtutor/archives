
## lab3




Accept the Github Classroom assignnment at 
[url.cs51.io/lab3](http://url.cs51.io/lab3). 

If this does not work _and a TF advises_, fork and then clone the repository at 
[http://github.com/cs51/lab3](http://github.com/cs51/lab3) 
and proceed as usual.

