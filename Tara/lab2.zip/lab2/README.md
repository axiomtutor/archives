
## lab2




Accept the Github Classroom assignnment at 
[url.cs51.io/lab2](http://url.cs51.io/lab2). 

If this does not work _and a TF advises_, fork and then clone the repository at 
[http://github.com/cs51/lab2](http://github.com/cs51/lab2) 
and proceed as usual.

